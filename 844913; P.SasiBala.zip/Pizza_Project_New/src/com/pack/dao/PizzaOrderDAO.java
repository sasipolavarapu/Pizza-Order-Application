package com.pack.dao;

import com.pack.model.PizzaOrder;
import com.pack.model.Customer;
import com.pack.model.Login;
import com.pack.exception.OrderNotFoundException;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;




public class PizzaOrderDAO implements IPizzaOrderDAO {

	@Autowired
	private SessionFactory sessionFactory;
	Session session;
	public void addUser(Login user) {
		   
		  session=sessionFactory.openSession();
		  Transaction tx=session.beginTransaction();
		  session.save(user);
		  tx.commit();
		  session.close(); 
	  }
	
	public int loginCheck(String username, String password) {
		// TODO Auto-generated method stub

		/* Session currentSession = sessionFactory.getCurrentSession(); */
		 Session session=sessionFactory.openSession();
		  Transaction tx=session.beginTransaction();
		Query q = session.createQuery("from Login where username=:id and password=:pass");
		q.setParameter("id", username);
		q.setParameter("pass", password);

		List results = q.list();
		
		tx.commit();
		  session.close(); 
		  int k=1,j=0;
		 
		if ((results!=null) && (results.size()>0)){
			return k;
		}
		else {
			return j;

		}
		
	}
	  
	  
	  
	 

	@Override
	public int login() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int placeOrder(Customer customer,PizzaOrder  pizza,double pTopping) {
		Session session=sessionFactory.openSession();
		Transaction tx=session.beginTransaction();
		session.save(customer);

		//order date calculation
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd");  
		LocalDateTime now = LocalDateTime.now();

		PizzaOrder po=new PizzaOrder();
		po.setId((int)Math.random());
		 po.setCustid(customer.getId()); 
		po.setTotalprice(pTopping+350);
		po.setOrderdate(dtf.format(now));
		
		session.save(po);
		int k=po.getId();
		tx.commit();
		session.close();
		return k;
	}


	public PizzaOrder getOrderById(int id)throws OrderNotFoundException {

		Session session=sessionFactory.openSession();
		session= sessionFactory.openSession();
		String hql="from PizzaOrder where id="+id;
		Query query = session.createQuery(hql);

		Iterator itr= query.iterate();
		PizzaOrder pizza=null;
		while (itr.hasNext())
		{
			pizza=(PizzaOrder)itr.next();
		}
		session.close();

		return pizza;
	}

	public int updateOrder(PizzaOrder pizza,double pTopping) {

		//System.out.println("into "+pizza.getId());
		Session session=sessionFactory.openSession();
		Transaction tx=session.beginTransaction();

		String hql="update  PizzaOrder set totalprice=:tot where id=:id";


		Query query = session.createQuery(hql);
		query.setParameter("id", pizza.getId());
		query.setParameter("tot", pTopping+350);
		query.executeUpdate();
		tx.commit();
		session.close();
		int k=pizza.getId();
		return k;

	}



	/*
	 * public int deleteOrder(int id) throws OrderNotFoundException{ Session
	 * session=sessionFactory.openSession(); Transaction
	 * tx=session.beginTransaction();
	 * 
	 * String hql="DELETE FROM PizzaOrder WHERE id="+id;
	 * 
	 * 
	 * Query query = session.createQuery(hql);
	 * 
	 * int k=query.executeUpdate(); tx.commit(); session.close(); return k;
	 * 
	 * }
	 */

	public int deleteOrder(PizzaOrder pizza){
		Session session=sessionFactory.openSession();
		Transaction tx=session.beginTransaction();

		String hql="DELETE FROM PizzaOrder WHERE id="+pizza.getId();
		Query query = session.createQuery(hql);
		int k=query.executeUpdate();
		tx.commit();
		session.close();
		return k;

	}

	public Object[] getData(int id,PizzaOrder pizza,Customer customer) throws OrderNotFoundException{
		 
		
		Session session=sessionFactory.openSession();
		Transaction tx=session.beginTransaction();

		String hql="select b.id,a.name,a.address,a.phone, b.orderdate, b.totalprice from  "
				+ "Customer a,PizzaOrder b where  a.id=b.custid  and b.id="+id;
		Query q=session.createQuery(hql);
		Object[] row=null;
		for(Iterator it=q.iterate();it.hasNext();){  	 
		      row = (Object[]) it.next();
		     }
	    tx.commit();
	    session.close();
		 return row;
	 }




	@Override
	public int modifyOrder(PizzaOrder order) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int displayOrder(PizzaOrder order) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int logout() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Customer getCustomerById(int custid) {
		// TODO Auto-generated method stub
		return null;
	}
}
package com.pack.model;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import org.hibernate.annotations.Proxy;
@Entity
@Table(name="customer")
@Proxy(lazy=false)
public class Customer {
	@Id
	@GeneratedValue
	@Column(name="custid")	
	int id;
	@Column(name="custname")
	String name;
	@Column(name="address")
	String address;
	@Column(name="phone")
	String phone;
	@Column(name="date")
	String date;
	@Column(name="toppings")
	double toppings;
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	
	public double getToppings() {
		return toppings;
	}
	public void setToppings(int toppings) {
		this.toppings = toppings;
	}


	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}

}

package com.pack.model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import org.hibernate.annotations.Proxy;
@Entity
@Table(name="pizzaorder")
@Proxy(lazy=false)
public class PizzaOrder {
	@Id
	@GeneratedValue
	@Column(name="orderid")	
	int id;

	/*
	 * @ManyToOne(cascade=CascadeType.ALL)
	 * 
	 * @JoinColumn(name = "custid",unique=true) private Customer customerOrder;
	 */

	@Column(name="custid")
	private int custid;
	
	
	public int getCustid() {
		return custid;
	}
	public void setCustid(int custid) {
		this.custid = custid;
	}
	@Column(name="totalprice")
	double totalprice;
	@Column(name="orderdate")
	String orderdate;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}

	
	public double getTotalprice() {
		return totalprice;
	}
	public void setTotalprice(double totalprice) {
		this.totalprice = totalprice;
	}
	
	public String getOrderdate() {
		return orderdate;
	}
	public void setOrderdate(String orderdate) {
		this.orderdate = orderdate;
	}

}

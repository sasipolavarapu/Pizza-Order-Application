package com.pack.controller;



import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.pack.exception.OrderNotFoundException;
import com.pack.model.Customer;
import com.pack.model.PizzaOrder;
import com.pack.model.Login;
import com.pack.service.PizzaOrderService;
 
@Controller
public class PizzaController {
 
	@Autowired
	private PizzaOrderService pizzaService;
 
	@RequestMapping("/login")  
	    public ModelAndView displayLogin()
	    {  
		 return new ModelAndView("login","login", new Login()); //return new ModelAndView("login"); 
	    }
	
		
	@RequestMapping("/login1")  
    public ModelAndView displayLogin1()
    {  
	 return new ModelAndView("home"); 
    }
	
	
		  @RequestMapping(value="/loginsuccess", method = RequestMethod.GET)
		  public ModelAndView toLogin(String username,String password) { 
			 int k=pizzaService.loginCheck(username, password);
			 if(k==1)
			 {
			 return new ModelAndView("home"); 
			 }
			 else return new ModelAndView("loginFail"); 
		  }
		  @RequestMapping("/placeorder")  
		    public ModelAndView toOrder()
		    {  
		        return new ModelAndView("orderhere","customer", new Customer());
		    }
			
		  @RequestMapping(value="/getorder", method = RequestMethod.GET) 
			public ModelAndView getOrder(Customer customer,@RequestParam("toppings")double top, Model m,PizzaOrder pizza) 
			{ 

				int k=pizzaService.placeOrder(customer,pizza,top);
				m.addAttribute("orderid", k);
				return new ModelAndView("ordersuccess");


			}
				@RequestMapping("/modifyorder")  
				public ModelAndView toModify()
				{  
					return new ModelAndView("modifyorder","customer", new Customer());
				}

				@RequestMapping(value = "/modify")   
				public String showupdateUser(@RequestParam("id") int id,PizzaOrder pizza,Model m) {
					try{
						pizza=pizzaService.getOrderById(id);
						if(pizza==null)
						{
							throw new OrderNotFoundException();
						}
					} catch (OrderNotFoundException e) {
						m.addAttribute("ex,e");
						return "exceptionPage";
					}
					m.addAttribute("modifyBean",pizza);
					return "showmodify";
				} 			

				@RequestMapping("/showModify")
				public String update(PizzaOrder pizza,@RequestParam("toppings")double top,Model m)
				{

					int k= pizzaService.updateOrder(pizza,top);
					m.addAttribute("orderid", k);
					return "ordersuccess";

				}





				@RequestMapping("/deleteorder")

				public ModelAndView toDelete()
				{

					return new ModelAndView("deleteorder");
				}


				/*
				 * @RequestMapping(value = "/showDeleteOrder") public ModelAndView
				 * showdeleteOrder(@RequestParam("id") int id,PizzaOrder pizza,Model m) {
				 * pizza=pizzaService.getOrderById(id); m.addAttribute("deleteBean",pizza);
				 * return new ModelAndView("showDelete"); }
				 */			
				@RequestMapping(value = "/showDeleteOrder") 
				public ModelAndView showdeleteOrder(@RequestParam("id") int id,PizzaOrder pizza,Model m) throws OrderNotFoundException
				{
					pizza=pizzaService.getOrderById(id);

					try {
						if(pizza==null) 
							throw new OrderNotFoundException();	

					}catch(OrderNotFoundException e) {
						m.addAttribute("ex",e);
						return  new ModelAndView("exceptionPage"); 
					}
					m.addAttribute("deleteBean",pizza);
					return new ModelAndView("showDelete");
				} 


				@RequestMapping("/delete")
				public String delete(PizzaOrder pizza,Model m)
				{	 
					int k= pizzaService.deleteOrder(pizza);			 			
					return "deletesuccess";	
				}


			
	 
	
@RequestMapping("/displayorder")
public ModelAndView toDisplay()
{
	return new ModelAndView("displayOrder");
}
@RequestMapping(value = "/showDisplayOrder") 
public ModelAndView showdisplayOrder(@RequestParam("id") int id,PizzaOrder pizza,Model m,Customer customer) throws OrderNotFoundException
{
	
	
	
	pizza=pizzaService.getOrderById(id);
	
	try {
		if(pizza==null) 
			throw new OrderNotFoundException();	

	}catch(OrderNotFoundException e) {
		m.addAttribute("ex",e);
		return  new ModelAndView("exceptionPage"); 
	}
	Object[] row=pizzaService.getData(id,pizza,customer);		
	m.addAttribute("row",row);
	return new ModelAndView("showOrder");

}


}

	

